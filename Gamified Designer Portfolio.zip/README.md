
  # Gamified Designer Portfolio

  This is a code bundle for Gamified Designer Portfolio. The original project is available at https://www.figma.com/design/sxwAnMLyvnTXzSS3r8LaSM/Gamified-Designer-Portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  